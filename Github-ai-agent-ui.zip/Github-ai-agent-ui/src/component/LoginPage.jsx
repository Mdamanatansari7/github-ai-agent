import React from 'react';
import './LoginPage.css';
import { FaGithub } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const LoginPage = () => {
    const navigate = useNavigate(); // Navigation setup

    const handleLogin = () => {
        // Optional: Yaha tum login validation bhi laga sakte ho
        navigate('/repositories'); // Redirect to Repo List page
    };

    return (
        <div className="login-container">
            <div className="login-card">
                <div className="github-icon">
                    <FaGithub size={48} />
                </div>
                <h2>Sign in to your account</h2>
                <p>Access your repositories and projects</p>

                <button className="github-button" onClick={handleLogin}>
                    <FaGithub size={20} style={{ marginRight: '8px' }} />
                    Continue with GitHub
                </button>

                <p className="terms">
                    By continuing, you agree to our <a href="/terms-of-service">Terms of Service</a> and <a href="/privacy-policy">Privacy Policy</a>
                </p>

                <hr className="divider" />

                <p className="support">Need help? <a href="/ContactSupportPage">Contact Support</a></p>
            </div>
        </div>
    );
};

export default LoginPage;
