import React from 'react';
import './PageStyles.css';

const TermsOfServicePage = () => {
    return (
        <div className="page-container">
            <h1>Terms of Service</h1>
            <p>By using this application, you agree to our terms and conditions.</p>

            <ul>
                <li>Respect the platform and other users.</li>
                <li>Do not misuse or abuse the system.</li>
                <li>All data is subject to our policies.</li>
                <li>Violation of terms may result in account suspension.</li>
            </ul>
        </div>
    );
};

export default TermsOfServicePage;
