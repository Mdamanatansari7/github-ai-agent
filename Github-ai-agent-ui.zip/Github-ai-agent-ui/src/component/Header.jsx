import React from 'react';
import './RepoListPage.css';

const Header = ({ searchTerm, setSearchTerm }) => {
    return (
        <header className="header">
            <div className="logo">GitHub Repositories</div>
            <input
                type="text"
                className="search-input"
                placeholder="Search repositories..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
            />
            <div className="icons">
                <span className="bell">🔔</span>
                <span className="avatar">JS</span>
            </div>
        </header>
    );
};

export default Header;
