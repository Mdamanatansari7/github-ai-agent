import React from 'react';
import './PageStyles.css';

const ContactSupportPage = () => {
    return (
        <div className="page-container">
            <h1>Contact Support</h1>
            <p>If you are experiencing any issues, please feel free to contact our support team.</p>

            <form className="support-form">
                <label>Name</label>
                <input type="text" placeholder="Enter your name" />

                <label>Email</label>
                <input type="email" placeholder="Enter your email" />

                <label>Message</label>
                <textarea rows="5" placeholder="Describe your issue"></textarea>

                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default ContactSupportPage;
