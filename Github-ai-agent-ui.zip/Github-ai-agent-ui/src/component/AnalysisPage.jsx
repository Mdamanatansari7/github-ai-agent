// AnalysisPage.jsx
import React, { useState } from 'react';
import { FaGithub, FaBell, FaSync, FaMagic, FaCheckCircle, FaDownload, FaCodeBranch } from 'react-icons/fa';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import mockSuggestions from '../data/mockSuggestions';
import mockRepos from '../data/mockRepos.json';
import './AnalysisPage.css';

const AnalysisPage = () => {
  const [selectedFile, setSelectedFile] = useState('Dashboard.tsx');
  const [view, setView] = useState('original');
  const [suggestions, setSuggestions] = useState([]);

  const runAnalysis = () => {
    setTimeout(() => setSuggestions(mockSuggestions), 1000);
  };

  const refresh = () => setSuggestions([]);
  const acceptAll = () => alert('All changes accepted.');
  const exportChanges = () => alert('Changes exported as JSON.');
  const createPR = () => alert('Pull Request Created!');

  return (
    <div className="analysis-page">
      <header className="github-header">
        <div className="left">
          <FaGithub size={28} />
          <span className="brand">AI Code Analysis</span>
        </div>
        <div className="right">
          <FaBell size={20} className="icon" />
          <img src="https://avatars.githubusercontent.com/u/1?v=4" alt="User" className="avatar" />
        </div>
      </header>

      <div className="breadcrumb">
        Repositories &gt; {mockRepos[0].name} &gt; AI Analysis
      </div>
      <div className="content">
        <div className="code-viewer">
          <div className="controls">
            <select value={selectedFile} onChange={(e) => setSelectedFile(e.target.value)}>
              <option>Dashboard.tsx</option>
              <option>Header.jsx</option>
              <option>Footer.jsx</option>
            </select>
            <div className="view-toggle">
              <div className={`toggle-box ${view === 'original' ? 'active' : ''}`} onClick={() => setView('original')}>
                <span>Original Code</span>
              </div>
              <div className={`toggle-box ${view === 'suggestions' ? 'active' : ''}`} onClick={() => setView('suggestions')}>
                <span>AI Suggestions</span>
              </div>
              <div className="toggle-box disabled">
                <span>Debug Logs</span>
              </div>
            </div>
          </div>
          <SyntaxHighlighter language="javascript" style={oneDark}>
            {view === 'original' ? `// Original ${selectedFile} code here...` : `// Suggested changes in ${selectedFile}...`}
          </SyntaxHighlighter>
        </div>

        <div className="analysis-panel">
          <div className="summary-buttons">
            <div className="summary">
              {suggestions.length} Suggestions
            </div>
            <div className="viewer-buttons">
              <button onClick={runAnalysis}><FaMagic style={{ marginRight: '8px' }} />Run Analysis</button>
              <button onClick={refresh}><FaSync style={{ marginRight: '8px' }} />Refresh</button>
            </div>
          </div>

          <div className="suggestions-list">
            {suggestions.map(sug => (
              <div className="suggestion-item" key={sug.id}>
                <span className={`severity ${sug.severity.toLowerCase()}`}>{sug.severity}</span>
                <strong>{sug.title}</strong>
                <details>
                  <summary>Details</summary>
                  <p>{sug.description}</p>
                </details>
              </div>
            ))}
          </div>

          <div className="viewer-buttons button-group">
            <button onClick={acceptAll}><FaCheckCircle style={{ marginRight: '5px' }} />Accept All</button>
            <button onClick={exportChanges}><FaDownload style={{ marginRight: '5px' }} />Export Changes</button>
            <button onClick={createPR}><FaCodeBranch style={{ marginRight: '5px' }} />Create PR</button>
          </div>
        </div>
      </div>

      <footer className="github-footer">
        <p>&copy; {new Date().getFullYear()} GitHub AI Agent. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default AnalysisPage;
