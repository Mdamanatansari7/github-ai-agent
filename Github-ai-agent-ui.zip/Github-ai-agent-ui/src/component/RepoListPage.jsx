import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaGithub } from 'react-icons/fa';
import Header from './Header';
import FilterBar from './FilterBar';
import RepoCard from './RepoCard';
import Pagination from './Pagination';
import mockRepos from '../data/mockRepos.json';
import './RepoListPage.css';

const RepoListPage = () => {
  const [repos, setRepos] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('All');
  const [sort, setSort] = useState('Last updated');
  const [currentPage, setCurrentPage] = useState(1);
  const reposPerPage = 6;

  const navigate = useNavigate();

  useEffect(() => {
    setRepos(mockRepos);
  }, []);

  const filteredRepos = repos
    .filter(repo => filter === 'All' || repo.privacy === filter)
    .filter(repo => repo.name.toLowerCase().includes(searchTerm.toLowerCase()))
    .sort((a, b) => {
      if (sort === 'Last updated') {
        return new Date(b.updatedAt) - new Date(a.updatedAt);
      } else if (sort === 'Stars') {
        return b.stars - a.stars;
      }
      return 0;
    });

  const indexOfLastRepo = currentPage * reposPerPage;
  const indexOfFirstRepo = indexOfLastRepo - reposPerPage;
  const currentRepos = filteredRepos.slice(indexOfFirstRepo, indexOfLastRepo);
  const totalPages = Math.ceil(filteredRepos.length / reposPerPage);

  return (
    <div>
      <Header searchTerm={searchTerm} setSearchTerm={setSearchTerm} />

      <div className="repo-container">
        <div className="repo-header">
          <div className="repo-title">
            <FaGithub size={28} style={{ marginRight: '10px' }} />
            <h2>Your Repositories</h2>
          </div>

          <div className="repo-actions">
            <button className="new-repo-btn">+ New Repository</button>
            <button className="ai-code-analysis-btn" onClick={() => navigate('/analysis')}>
              + AI Code Analysis
            </button>
          </div>
        </div>

        <FilterBar filter={filter} setFilter={setFilter} />

        <div className="sort-bar">
          <label>Sort: </label>
          <select value={sort} onChange={(e) => setSort(e.target.value)}>
            <option>Last updated</option>
            <option>Stars</option>
          </select>
        </div>

        <div className="repo-grid">
          {currentRepos.map(repo => (
            <RepoCard key={repo.id} repo={repo} />
          ))}
        </div>

        <Pagination totalPages={totalPages} currentPage={currentPage} setCurrentPage={setCurrentPage} />
      </div>
    </div>
  );
};

export default RepoListPage;
