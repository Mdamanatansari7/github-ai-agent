import React from 'react';
import './RepoListPage.css';

const FilterBar = ({ filter, setFilter }) => {
    const filters = ['All', 'Public', 'Private', 'Archived'];

    return (
        <div className="filter-bar">
            {filters.map(f => (
                <button
                    key={f}
                    className={filter === f ? 'active' : ''}
                    onClick={() => setFilter(f)}
                >
                    {f}
                </button>
            ))}
        </div>
    );
};

export default FilterBar;
