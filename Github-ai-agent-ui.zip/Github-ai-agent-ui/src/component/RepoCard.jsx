import React from 'react';
import './RepoListPage.css';

const RepoCard = ({ repo }) => {
    return (
        <div className="repo-card">
            <div className="repo-header">
                <span className="repo-name">{repo.name}</span>
                <span className={`privacy ${repo.privacy.toLowerCase()}`}>{repo.privacy}</span>
            </div>
            <p>{repo.description}</p>
            <div className="repo-footer">
                <span className="language">{repo.language}</span>
                <span>⭐ {repo.stars}</span>
                <span>Updated {new Date(repo.updatedAt).toDateString()}</span>
            </div>
        </div>
    );
};

export default RepoCard;
