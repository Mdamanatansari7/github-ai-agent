import React from 'react';
import './PageStyles.css';

const PrivacyPolicyPage = () => {
    return (
        <div className="page-container">
            <h1>Privacy Policy</h1>
            <p>Your privacy is very important to us. We do not sell your data to third parties.</p>

            <ul>
                <li>We collect basic user information for login and usage tracking.</li>
                <li>Your data is securely stored and protected.</li>
                <li>We may use cookies to improve user experience.</li>
                <li>You can contact us anytime to review or delete your data.</li>
            </ul>
        </div>
    );
};

export default PrivacyPolicyPage;
