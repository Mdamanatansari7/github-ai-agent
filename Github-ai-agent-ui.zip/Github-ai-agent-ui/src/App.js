import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './component/LoginPage';
import RepoListPage from './component/RepoListPage';
import AnalysisPage from './component/AnalysisPage';
import ContactSupportPage from './component/ContactSupportPage';
import TermsOfServicePage from './component/TermsOfServicePage';
import PrivacyPolicyPage from './component/PrivacyPolicyPage';

function App() {
  return (
    <Router>
      <Routes>
        {/* GitHub-style login page */}
        <Route path="/login" element={<LoginPage />} />

        {/* Repository list page */}
        <Route path="/repositories" element={<RepoListPage />} />

        {/* Analysis page */}
        <Route path="/analysis" element={<AnalysisPage />} />

        {/* Contact support */}
        <Route path="/contact-support" element={<ContactSupportPage />} />

        {/* Terms of Service */}
        <Route path="/terms-of-service" element={<TermsOfServicePage />} />

        {/* Privacy Policy */}
        <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />

        {/* Redirect all unknown routes to login */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
