const mockSuggestions = [
    {
        id: 1,
        severity: 'Medium',
        title: 'Memory Leak Prevention',
        description: 'Ensure that all event listeners and subscriptions are properly cleaned up in useEffect to prevent memory leaks.'
    },
    {
        id: 2,
        severity: 'High',
        title: 'Error Boundary Implementation',
        description: 'Consider adding error boundaries to catch JavaScript errors anywhere in the component tree and display a fallback UI.'
    },
    {
        id: 3,
        severity: 'Medium',
        title: 'Null Safety Improvements',
        description: 'Ensure proper null checks and default values to improve the robustness of the application.'
    },
    {
        id: 4,
        severity: 'Low',
        title: 'Loading State Enhancement',
        description: 'Improve loading state handling to provide better feedback to users during async operations.'
    }
];

export default mockSuggestions;
